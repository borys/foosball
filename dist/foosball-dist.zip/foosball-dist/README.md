To run, install neccessary tools:
### npm install

Then run server (it runs json-server)

### `npm run serve`

And serve app (it runs live-server )

### `npm run start`
